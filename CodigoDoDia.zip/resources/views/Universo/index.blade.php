@extends('Default.layout')
@section('main')
    <h1>Olá!</h1>
@endsection