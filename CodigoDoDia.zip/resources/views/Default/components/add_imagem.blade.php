<div class="formulario formComponent">
    <h1>Cadastrar</h1>
    <form action="{{route('dicas.novo.post')}}" method="post" enctype="multipart/form-data">
        <select name="" id="">
            <option value="">teste</option>
        </select>
    </form>
</div>