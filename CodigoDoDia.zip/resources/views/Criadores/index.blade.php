@extends('Default.layout')
@section('section')
    <div class="postagem">
        <img class="designImg" src="{{asset('image/Capturar.PNG')}}" alt="">
        <h1>Página inicial</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta alias accusantium provident consectetur quisquam ut modi ipsam atque? Molestiae sunt eius accusantium officia iusto culpa debitis quis id temporibus tenetur..</p>
        <img class="linguagem" src="{{asset('image/free.png')}}" alt="">
    </div>
@endsection