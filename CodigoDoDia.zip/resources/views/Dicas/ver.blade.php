@extends('Default.layout')
@section('section')
    <div class="postagem ver">
        <h1>{{$dica->titulo}}</h1>
        <div class="add-info">
            <span>Autor: {{$dica->usuario->nome}}</span>
            <span>{{$dica->dataFormatadaUsuario()}}</span>
        </div>
        <p>{{$dica->descricao}}</p>
        @php
            echo $dica->html;
        @endphp
    </div>
@endsection

@section('javascript')
    
@endsection