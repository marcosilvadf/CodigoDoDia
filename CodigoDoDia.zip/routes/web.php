<?php

use App\Http\Controllers\DesignController;
use App\Http\Controllers\dicasController;
use App\Http\Controllers\UniversoController;
use App\Http\Controllers\UsuarioController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('dicas.principal');
    //return view('Inicio.Inicio');
});

Route::group(['prefix' => 'dicas'], function () {
    Route::get('/', [DicasController::class, 'index'])->name('dicas.principal');
    Route::get('/post/{slug}', [DicasController::class, 'show'])->name('dicas.ver');
    Route::get('/novo', [DicasController::class, 'create'])->name('dicas.novo')->middleware('verificarUsuarioLogado');
    Route::post('/novo', [DicasController::class, 'store'])->name('dicas.novo.post');
    Route::post('/', [DicasController::class, 'salvarIdSession'])->name('dicas.salvar.id');
    Route::get('/lista', [DicasController::class, 'lista'])->name('dicas.lista')->middleware('verificarUsuarioLogado');
    Route::get('/editar', [DicasController::class, 'edit'])->name('dicas.edit')->middleware('verificarUsuarioLogado');
    Route::post('/editar', [DicasController::class, 'update'])->name('dicas.edit.post');
    Route::get('/deletar', [DicasController::class, 'destroy'])->name('dicas.delete')->middleware('verificarUsuarioLogado');
});

Route::group(['prefix' => 'universo'], function () {
    Route::get('/', [UniversoController::class, 'index']);
});

Route::group(['prefix' => 'design'], function () {
    Route::get('/', [DesignController::class, 'index'])->name('design.principal');
});

Route::group(['prefix' => 'usuario'], function () {
    Route::get('/', [UsuarioController::class, 'index'])->name('usuario.principal')->middleware('verificarUsuarioLogado');
    Route::get('/cadastrar', [UsuarioController::class, 'create'])->name('usuario.novo');
    Route::post('/cadastrar', [UsuarioController::class, 'store'])->name('usuario.novo.post');
    Route::get('/login', [UsuarioController::class, 'login'])->name('usuario.login');
    Route::post('/login', [UsuarioController::class, 'logif'])->name('usuario.login.post');
    Route::get('/perfil', [UsuarioController::class, 'perfil'])->name('usuario.perfil')->middleware('verificarUsuarioLogado');
    Route::get('/deslogar', [UsuarioController::class, 'deslogar'])->name('usuario.deslogar');
    Route::get('/editar', [UsuarioController::class, 'edit'])->name('usuario.edit')->middleware('verificarUsuarioLogado');
    Route::post('/editar', [UsuarioController::class, 'update'])->name('usuario.edit.post');
    Route::get('/deletar', [UsuarioController::class, 'destroy'])->name('usuario.delete')->middleware('verificarUsuarioLogado');
    Route::get('/recuperar', [UsuarioController::class, 'recuperar'])->name('usuario.recuperar');
    Route::post('/recuperar', [UsuarioController::class, 'mudarSenha'])->name('usuario.recuperar.post');
});