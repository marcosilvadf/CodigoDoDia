//tipo = true == link interno, tipo = false == link externo
function abrirLink(link, tipo) {
    if (tipo) {
        window.location.href = link
    } else {
        window.open(link, '_blank')        
    }
}

$(document).ready(() => {
    $('body').removeClass('ativo');
})

$(window).on('pageshow', function(event) {
    if (event.originalEvent.persisted) {
        $('body').removeClass('ativo');
    }
  });