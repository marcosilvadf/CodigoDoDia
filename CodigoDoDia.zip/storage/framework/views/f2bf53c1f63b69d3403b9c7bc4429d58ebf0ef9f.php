
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>?<?php echo e(getenv('APP_VERSION')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
<div class="formulario">
    <h1>Cadastrar</h1>
    <?php if($editar): ?>
        <form action="<?php echo e(route('usuario.edit.post')); ?>" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" id="id" value="<?php echo e($usuario->id); ?>">
    <?php else: ?>
        <form action="<?php echo e(route('usuario.novo.post')); ?>" method="post" enctype="multipart/form-data">
    <?php endif; ?>
        <?php echo csrf_field(); ?>
        <label for="imagem" id="conteudoImagem">
            <img <?php if($editar): ?> src="<?php echo e(asset($usuario->foto)); ?>" <?php else: ?> src="<?php echo e(asset('image/usuario1.png')); ?>" <?php endif; ?> alt="" class="perfil">
            <span id="nomeImagem">Selecione uma imagem de perfil</span>
        </label>
        <input type="file" name="imagem" id="imagem" accept="image/*">
        <input type="text" name="nome" id="nome" placeholder="Nome:" value="<?php echo e($usuario->nome ?? ''); ?>" minlength="4" maxlength="20" required>
        <input type="email" name="email" id="email" placeholder="E-mail:" <?php if($editar): ?> readonly <?php endif; ?> value="<?php echo e($usuario->email ?? ''); ?>" required>        
        
        <?php if(!$editar): ?>
            <input type="password" name="senha" id="senha" placeholder="Senha:" minlength="4" maxlength="20" required>
            <input type="password" name="" id="confirmsenha" placeholder="Confirme a Senha:"minlength="4" maxlength="20" required>
        <?php endif; ?>

        <input type="submit" id="btnSubmit" value="<?php if($editar): ?> salvar <?php else: ?> cadastrar <?php endif; ?>" class="enviar">
    </form>
    <?php if(!$editar): ?>
        <a class="btn" href="<?php echo e(route('usuario.login')); ?>" style="align-self: flex-end">Já tem cadastro?</a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/form.js')); ?>?<?php echo e(getenv('APP_VERSION')); ?>"></script>
    <script>

        $('#btnSubmit').click(function (e) { 
            if ($('#senha').val() != $('#confirmsenha').val()) {
                e.preventDefault()
                alert('Senhas não coincidem!')
            }
            let reader = new FileReader()

            if(file.files.length <= 0 && !($("#id").length)) {
                e.preventDefault()
                alert('Adicione uma foto de perfil!')                
            }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Usuario/form.blade.php ENDPATH**/ ?>