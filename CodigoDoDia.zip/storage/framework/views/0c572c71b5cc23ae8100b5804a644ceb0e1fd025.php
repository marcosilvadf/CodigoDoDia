
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>?<?php echo e(getenv('APP_VERSION')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
<div class="formulario">
    <h1><?php echo e($edit ? "Editar" : "Cadastrar"); ?></h1>
    <?php if($edit): ?>
        <form action="<?php echo e(route('dicas.edit.post')); ?>" method="post">
        <a class="btn" onclick="certeza('<?php echo e($dica->titulo); ?>', <?php echo e($dica->id); ?>)" style="align-self: flex-end">Excluir</a>
        <input type="hidden" name="dica_id" value="<?php echo e($dica->id); ?>">
    <?php else: ?>
        <form action="<?php echo e(route('dicas.novo.post')); ?>" method="post">
    <?php endif; ?>
        <?php echo csrf_field(); ?>
        <input type="text" name="titulo" id="titulo" placeholder="Título" minlength="10" maxlength="50" value="<?php echo e($edit ? "$dica->titulo" : ''); ?>" required>
        <input type="text" name="desc" id="desc" placeholder="Descrição" value="<?php echo e($edit ? "$dica->descricao" : ''); ?>" minlength="10" maxlength="80" required>
        <select name="linguagem" id="linguagem" required>
            <option disabled selected value="0">Selecione a linguagem</option>
            <option <?php if($edit): ?> <?php if($dica->linguagem == 'js'): ?> selected <?php endif; ?> <?php endif; ?> value="js">Javascript</option>
            <option <?php if($edit): ?> <?php if($dica->linguagem == 'php'): ?> selected <?php endif; ?> <?php endif; ?> value="php">PHP</option>
            <option <?php if($edit): ?> <?php if($dica->linguagem == 'java'): ?> selected <?php endif; ?> <?php endif; ?> value="java">Java</option>
        </select>
        <textarea name="cod" id="cod" cols="30" rows="10" placeholder="Código HTML" required><?php echo e($edit ? "$dica->html" : ''); ?></textarea>
        <input type="submit" value="<?php echo e($edit ? "Editar" : "Cadastrar"); ?>" class="enviar">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        function certeza(nome, id) {
            if (confirm(`Deseja deletar o registro: ${nome}?`)) {
                salvarIdSession('<?php echo e(route("dicas.salvar.id")); ?>', '<?php echo e(route("dicas.delete")); ?>', id, 3)
            }
        }

        $('.enviar').click(function (e) { 
            if($('#linguagem').val() == null) {
                e.preventDefault()
                alert('Selecione uma linguagem!')
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Dicas/form.blade.php ENDPATH**/ ?>