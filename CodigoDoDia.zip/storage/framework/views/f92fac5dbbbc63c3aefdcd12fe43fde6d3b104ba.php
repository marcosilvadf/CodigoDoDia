
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>?<?php echo e(getenv('APP_VERSION')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
<div class="formulario">
    <h1>Login</h1>
    <form action="<?php echo e(route('usuario.login.post')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" id="email" placeholder="E-mail:" required>
        <input type="password" name="senha" id="senha" placeholder="Senha:" minlength="4" maxlength="20" required>
        <input type="submit" value="login" class="enviar">
    </form>
    <a class="btn" href="<?php echo e(route('usuario.novo')); ?>" style="align-self: flex-end">Não tem cadastro?</a>
    <a class="btn" href="<?php echo e(route('usuario.recuperar')); ?>" style="align-self: flex-end">Esquceu a senha?</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Usuario/login.blade.php ENDPATH**/ ?>