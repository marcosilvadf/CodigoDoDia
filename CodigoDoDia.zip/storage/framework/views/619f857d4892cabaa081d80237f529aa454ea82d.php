
<?php $__env->startSection('section'); ?>
<input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
    <?php $__currentLoopData = $dicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="postagem" onclick="abrirLink('<?php echo e(route('dicas.ver', ['slug' => $dica->slug])); ?>', true)">
            <h1><?php echo e($dica->titulo); ?></h1>
            <p><?php echo e($dica->descricao); ?></p>
            <img class="linguagem" src="<?php echo e(asset('svg/'. $dica->linguagem .'.svg')); ?>" alt="">
        </div>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>        
        var csrfToken = $('#token').val()
        function removerAdicionarSession(id) {
            return new Promise(resolve => {
                sessionStorage.removeItem("id")
                while (sessionStorage.getItem("id") === null) {
                    sessionStorage.setItem("id", id)
                }
                resolve(sessionStorage.getItem("id"))
            })
        }

        async function guardarIdPostagem(id) {
            var idItem = await removerAdicionarSession(id)
        }        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Dicas/index.blade.php ENDPATH**/ ?>