
<?php $__env->startSection('section'); ?>
    <div class="postagem ver">
        <h1><?php echo e($dica->titulo); ?></h1>
        <div class="add-info">
            <span>Autor: <?php echo e($dica->usuario->nome); ?></span>
            <span><?php echo e($dica->dataFormatadaUsuario()); ?></span>
        </div>
        <p><?php echo e($dica->descricao); ?></p>
        <?php
            echo $dica->html;
        ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Dicas/ver.blade.php ENDPATH**/ ?>