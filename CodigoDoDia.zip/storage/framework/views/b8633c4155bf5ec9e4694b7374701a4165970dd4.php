
<?php $__env->startSection('section'); ?>
    <div class="postagem">
        <img class="designImg" src="<?php echo e(asset('image/Capturar.PNG')); ?>" alt="">
        <h1>Página inicial</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta alias accusantium provident consectetur quisquam ut modi ipsam atque? Molestiae sunt eius accusantium officia iusto culpa debitis quis id temporibus tenetur..</p>
        <img class="linguagem" src="<?php echo e(asset('image/free.png')); ?>" alt="">
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Design/index.blade.php ENDPATH**/ ?>