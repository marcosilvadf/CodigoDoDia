
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>?<?php echo e(getenv('APP_VERSION')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
<div class="perfil">
    <h1>Perfil</h1>
    <img src='<?php echo e(asset("$usuario->foto")); ?>' alt="">
    <span><?php echo e($usuario->nome); ?></span>
    <?php if($usuario->tipo > 0): ?>
        <a class="btn" href="<?php echo e(route('dicas.lista')); ?>">Publicações</a>    
    <?php endif; ?>
    <a class="btn" href="<?php echo e(route('usuario.edit')); ?>">Editar Perfil</a>
    <a class="btn" href="<?php echo e(route('usuario.deslogar')); ?>">Sair</a>
    <a class="btn" onclick="certeza()">Excluir Perfil</a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/form.js')); ?>?<?php echo e(getenv('APP_VERSION')); ?>"></script>
    <script>
        function certeza(){
            if (confirm('Tem certeza que deseja apagar seu perfil? Isso apagará todos os dados e não poderão ser recuperados!')) {
                abrirLink('<?php echo e(route("usuario.delete")); ?>', true)
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Usuario/perfil.blade.php ENDPATH**/ ?>