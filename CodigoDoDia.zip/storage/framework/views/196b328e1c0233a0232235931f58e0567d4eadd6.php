
<?php $__env->startSection('section'); ?>
    <div class="postagem ver">
        <h1>Preview de imagem no formulário</h1>
        <div class="add-info">
            <span>Autor: Antonio Marcos</span>
            <span>18/06/2023</span>
        </div>
        <p>Veja a imagem assim que o usuário a coloque em um formulário no input:file.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Funcoes/ver.blade.php ENDPATH**/ ?>