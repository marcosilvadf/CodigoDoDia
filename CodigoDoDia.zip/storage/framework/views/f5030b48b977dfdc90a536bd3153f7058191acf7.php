
<?php $__env->startSection('main'); ?>
    <h1>Olá!</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Universo/index.blade.php ENDPATH**/ ?>