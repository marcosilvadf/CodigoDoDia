
<?php $__env->startSection('section'); ?>
<div class="lista">
    <h1>Lista</h1>    
    <a class="btn" href="<?php echo e(route('dicas.novo')); ?>" style="align-self: flex-end">Nova</a>
    <table>
        <tr>
        </tr>
        <?php $__currentLoopData = $dicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr onclick="salvarIdSession('<?php echo e(route('dicas.salvar.id')); ?>', '<?php echo e(route('dicas.edit')); ?>', '<?php echo e($dica->id); ?>', 2)">
                <td><?php echo e($dica->titulo); ?></td>
                <td><img class="linguagem" src="<?php echo e(asset('svg/'. $dica->linguagem .'.svg')); ?>" alt=""></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Dicas/lista.blade.php ENDPATH**/ ?>