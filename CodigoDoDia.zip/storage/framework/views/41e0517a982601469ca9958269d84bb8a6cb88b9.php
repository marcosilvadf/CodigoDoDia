<div class="formulario formComponent">
    <h1>Cadastrar</h1>
    <form action="<?php echo e(route('dicas.novo.post')); ?>" method="post" enctype="multipart/form-data">
        <select name="" id="">
            <option value="">teste</option>
        </select>
    </form>
</div><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Default/components/add_imagem.blade.php ENDPATH**/ ?>