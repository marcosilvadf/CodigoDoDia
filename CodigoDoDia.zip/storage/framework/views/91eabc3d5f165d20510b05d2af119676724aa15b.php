
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>?<?php echo e(getenv('APP_VERSION')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
<div class="formulario">
    <h1>Recuperar</h1>
    <form action="<?php echo e(route('usuario.recuperar.post')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" id="email" placeholder="E-mail:" required>
        <input type="password" name="senha" id="senha" placeholder="Senha:" minlength="4" maxlength="20" required>
            <input type="password" name="" id="confirmsenha" placeholder="Confirme a Senha:" minlength="4" maxlength="20" required>
        <input type="submit" id="btnSubmit" value="alterar senha" class="enviar">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        $('#btnSubmit').click(function (e) { 
            if ($('#senha').val() != $('#confirmsenha').val()) {
                e.preventDefault()
                alert('Senhas não coincidem!')
            }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Default.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Antonio Marcos\Documents\Site\CodigoDoDia\resources\views/Usuario/recuperar.blade.php ENDPATH**/ ?>